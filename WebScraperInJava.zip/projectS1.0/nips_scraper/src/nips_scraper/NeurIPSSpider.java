package nips_scraper;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NeurIPSSpider {

    // Target years to download data from
    private static final Set<String> TARGET_YEARS = Set.of("2013");
    
    // JSON metadata list
    private final List<PaperMetadata> metadataList = new ArrayList<>();
    
    // Counters
    private int downloadCount = 0;
    private int failedCount = 0;

    public static void main(String[] args) {
        new NeurIPSSpider().startCrawling();
    }

    public void startCrawling() {
        try {
            Document doc = Jsoup.connect("https://papers.nips.cc/").get();
            parseMainPage(doc);
        } catch (IOException e) {
            System.err.println("Failed to fetch main page: " + e.getMessage());
        }
        
        System.out.println("\nScraping completed!");
        System.out.println("Successfully downloaded: " + downloadCount);
        System.out.println("Failed downloads: " + failedCount);
    }

    private void parseMainPage(Document doc) {
        doc.select("div.col-sm ul li a").forEach(link -> {
            String href = link.attr("href");
            Matcher matcher = Pattern.compile("\\d{4}").matcher(href);
            if (matcher.find()) {
                String year = matcher.group();
                if (TARGET_YEARS.contains(year)) {
                    processYearPage(year, href);
                }
            }
        });
    }

    private void processYearPage(String year, String href) {
        try {
            Document yearPage = Jsoup.connect("https://papers.nips.cc" + href).get();
            parseConferenceList(yearPage, year);
        } catch (IOException e) {
            System.err.println("Failed to fetch year page: " + e.getMessage());
        }
    }

    private void parseConferenceList(Document doc, String year) {
        Elements conferenceLinks = doc.select("div.container-fluid div ul li a");
        if (conferenceLinks.isEmpty()) {
            System.err.println("No conferences found for " + year);
            return;
        }

        conferenceLinks.forEach(link -> {
            String href = link.attr("href");
            processConferencePage(year, href);
        });
        
        saveMetadata(year);
    }

    private void processConferencePage(String year, String href) {
        try {
            Document conferencePage = Jsoup.connect("https://papers.nips.cc" + href).get();
            parsePaperDetails(conferencePage, year);
        } catch (IOException e) {
            System.err.println("Failed to fetch conference page: " + e.getMessage());
        }
    }

    private void parsePaperDetails(Document doc, String year) {
        String title = doc.select("h4").first().text();
        String authors = doc.select("body > div.container-fluid > div > p:nth-child(6) > i").first().text();
        String pdfLink = findPdfLink(doc);

        PaperMetadata metadata = new PaperMetadata(title, authors, pdfLink, year);
        metadataList.add(metadata);

        if (pdfLink != null) {
            downloadPdfFile(year, title, authors, pdfLink);
        } else {
            handleFailedDownload(title, year);
        }
    }

    private String findPdfLink(Document doc) {
        return doc.select("div.container-fluid > div > div > a").stream()
            .filter(link -> link.text().equals("Paper"))
            .findFirst()
            .map(link -> "https://papers.nips.cc" + link.attr("href"))
            .orElse(null);
    }

    private void downloadPdfFile(String year, String title, String authors, String pdfLink) {
        try {
            String cleanTitle = cleanFilename(title);
            String cleanAuthors = cleanFilename(authors);
            String filePath = buildFilePath(year, cleanTitle, cleanAuthors);
            
            Files.createDirectories(Paths.get("H:/DataScrappedByJava/" + year));
            if (downloadPdf(pdfLink, filePath)) {
                System.out.println("Downloaded: " + filePath);
                downloadCount++;
            } else {
                handleFailedDownload(title, year);
            }
        } catch (IOException e) {
            System.err.println("Directory creation failed: " + e.getMessage());
            handleFailedDownload(title, year);
        }
    }

    private String buildFilePath(String year, String title, String authors) {
        return "H:/DataScrappedByJava/" + year + "/" + title + " - " + authors + ".pdf";
    }

    private boolean downloadPdf(String url, String filePath) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(url);
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                if (response.getStatusLine().getStatusCode() == 200) {
                    try (FileOutputStream fos = new FileOutputStream(filePath)) {
                        response.getEntity().writeTo(fos);
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Download error: " + e.getMessage());
        }
        return false;
    }

    private void handleFailedDownload(String title, String year) {
        System.err.println("Failed to download: " + title + " (" + year + ")");
        failedCount++;
    }

    private void saveMetadata(String year) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            File outputFile = new File("H:/DataScrappedByJava/" + year + "/metadata.json");
            mapper.writerWithDefaultPrettyPrinter().writeValue(outputFile, metadataList);
            System.out.println("Metadata saved for " + year);
        } catch (IOException e) {
            System.err.println("Failed to save metadata: " + e.getMessage());
        }
    }

    private String cleanFilename(String name) {
        return (name == null || name.isEmpty()) 
            ? "Unknown" 
            : name.replaceAll("[^\\w\\s-]", "").trim().replaceAll("\\s+", "_");
    }

    static class PaperMetadata {
        private final String title;
        private final String authors;
        private final String pdfLink;
        private final String year;

        public PaperMetadata(String title, String authors, String pdfLink, String year) {
            this.title = title;
            this.authors = authors;
            this.pdfLink = pdfLink;
            this.year = year;
        }

        // Getters required for JSON serialization
        public String getTitle() { return title; }
        public String getAuthors() { return authors; }
        public String getPdfLink() { return pdfLink; }
        public String getYear() { return year; }
    }
}